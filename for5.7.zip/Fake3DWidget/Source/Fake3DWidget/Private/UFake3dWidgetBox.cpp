// Copyright lurongjiu 2026 All Rights Reserved.


#include "UFake3dWidgetBox.h"

#include "Fake3DWidgetModule.h"


/*
UFake3dWidgetBox::UFake3dWidgetBox(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	Rotation3D = FRotator::ZeroRotator;
	FOV = 90.f;
#if WITH_EDITOR
	bShowEffectsInDesigner = true;
#endif // WITH_EDITOR

	}
	*/

void UFake3dWidgetBox::SetRotation(FRotator NewRotation)
{
	Rotation3D = NewRotation;
	if (MyFake3DWidgetBox.IsValid())
	{
		MyFake3DWidgetBox->SetRotation(Rotation3D);
	}
}

void UFake3dWidgetBox::SetFOV(float NewFOV)
{
	FOV = NewFOV;
	if (MyFake3DWidgetBox.IsValid())
	{
		MyFake3DWidgetBox->SetFOV_Perspective(FOV);
	}
}

void UFake3dWidgetBox::SetPivot(FVector2D NewPivot)
{
	Pivot = NewPivot;
	if (MyFake3DWidgetBox.IsValid())
	{
		MyFake3DWidgetBox->SetPivot(Pivot);
	}
}

void UFake3dWidgetBox::SetRenderingPhase(int32 RenderPhase, int32 TotalPhases)
{
	Phase = RenderPhase;
	PhaseCount = TotalPhases;
	
	if ( PhaseCount < 1 )
	{
		PhaseCount = 1;
	}

	if (MyFake3DWidgetBox.IsValid())
	{
		MyFake3DWidgetBox->SetRenderingPhase(Phase, PhaseCount);
	}
}

void UFake3dWidgetBox::SetRenderOnPhase(bool InRenderOnPhase)
{
	RenderOnPhase = InRenderOnPhase;
	
	if (MyFake3DWidgetBox.IsValid())
	{
		MyFake3DWidgetBox->SetRenderOnPhase(RenderOnPhase);
	}
}

void UFake3dWidgetBox::RequestRender()
{
	if ( MyFake3DWidgetBox.IsValid() )
	{
		MyFake3DWidgetBox->RequestRender();
	}
}

#if WITH_EDITOR
const FText UFake3dWidgetBox::GetPaletteCategory()
{
	return FText::FromString("Fake3DWidget");
}
#endif

void UFake3dWidgetBox::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
	MyFake3DWidgetBox.Reset();
}

TSharedRef<SWidget> UFake3dWidgetBox::RebuildWidget()
{
	MyFake3DWidgetBox = SNew(SFake3DWidgetBox)
//		.RenderOnInvalidation(RenderOnInvalidation)
		.RenderOnPhase(RenderOnPhase)
		.Phase(Phase)
		.PhaseCount(PhaseCount)
#if STATS
		.StatId( FName( *FString::Printf(TEXT("%s [%s]"), *GetFName().ToString(), *GetClass()->GetName() ) ) )
#endif
		;

	if ( GetChildrenCount() > 0 )
	{
		MyFake3DWidgetBox->SetContent(GetContentSlot()->Content ? GetContentSlot()->Content->TakeWidget() : SNullWidget::NullWidget);
	}
	
	return MyFake3DWidgetBox.ToSharedRef();

}

void UFake3dWidgetBox::SynchronizeProperties()
{
	//任何属性变化都会调用, 未来优化为独立属性调用独立函数(这个用于编辑器时, 不会通过函数调用的情况)
	Super::SynchronizeProperties();
	
	if (! MyFake3DWidgetBox.IsValid()) return;

#if WITH_EDITOR
	MyFake3DWidgetBox->SetIsDesignTime(IsDesignTime());
	MyFake3DWidgetBox->SetShowEffectsInDesigner(bShowEffectsInDesigner);
#endif // WITH_EDITOR
	
	MyFake3DWidgetBox->SetRotation(Rotation3D);
	MyFake3DWidgetBox->SetFOV_Perspective(FOV);
	MyFake3DWidgetBox->SetPivot(Pivot);
	MyFake3DWidgetBox->UpdateFrontFace(RenderFrontFace);
	MyFake3DWidgetBox->UpdateBackFace(RenderBackFace);
	MyFake3DWidgetBox->SetWorld(GetWorld());
	
	//MyFake3DWidgetBox->Invalidate(EInvalidateWidgetReason::Paint);
}

void UFake3dWidgetBox::OnSlotAdded(UPanelSlot* InSlot)
{
	// Add the child to the live slot if it already exists
	if ( MyFake3DWidgetBox.IsValid() )
	{
		MyFake3DWidgetBox->SetContent(InSlot->Content ? InSlot->Content->TakeWidget() : SNullWidget::NullWidget);
	}
}

void UFake3dWidgetBox::OnSlotRemoved(UPanelSlot* InSlot)
{
	// Remove the widget from the live slot if it exists.
	if ( MyFake3DWidgetBox.IsValid() )
	{
		MyFake3DWidgetBox->SetContent(SNullWidget::NullWidget);
	}
}
