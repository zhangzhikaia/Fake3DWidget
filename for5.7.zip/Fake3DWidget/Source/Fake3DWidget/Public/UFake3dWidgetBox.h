// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "SFake3DWidgetBox.h"
#include "Components/ContentWidget.h"
#include "UFake3dWidgetBox.generated.h"

/**
 * 
 */
UCLASS()
class FAKE3DWIDGET_API UFake3dWidgetBox : public UContentWidget
{
public:
	GENERATED_BODY()
	//直接默认赋值比构造时赋值更直观
	//UFake3dWidgetBox(const FObjectInitializer& ObjectInitializer);
	
	/**/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D")
	FRotator Rotation3D = FRotator::ZeroRotator;

	/**/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D", meta = (UIMin = "0.001", UIMax = "120", ClampMin = "0.001", ClampMax = "120.0", Units = deg))
	float FOV = 90.f;

	/**/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D")
	FVector2D Pivot = FVector2D(0.5f, 0.5f);

	/**/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D")
	bool RenderFrontFace = true;

	/**/
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D")
	bool RenderBackFace = false;
	
#if WITH_EDITORONLY_DATA
	/**
	 * If true, rendering occurs in designer
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Fake3D")
	bool bShowEffectsInDesigner = true;
#endif

	/*/**
 	 * Should this widget redraw the contents it has every time it receives an invalidation request
 	 * from it's children, similar to the invalidation panel.
 	 #1#
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Render Rules")
	bool RenderOnInvalidation = false;*/
	
	/**
	 * Should this widget redraw the contents it has every time the phase occurs.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Render Rules")
	bool RenderOnPhase = true;

	/**
	 * The Phase this widget will draw on.
	 *
	 * If the Phase is 0, and the PhaseCount is 1, the widget will be drawn fresh every frame.
	 * If the Phase were 0, and the PhaseCount were 2, this retainer would draw a fresh frame every
	 * other frame.  So in a 60Hz game, the UI would render at 30Hz.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Render Rules", meta=(UIMin=0, ClampMin=0))
	int32 Phase = 0;

	/**
	 * The PhaseCount controls how many phases are possible know what to modulus the current frame 
	 * count by to determine if this is the current frame to draw the widget on.
	 * 
	 * If the Phase is 0, and the PhaseCount is 1, the widget will be drawn fresh every frame.  
	 * If the Phase were 0, and the PhaseCount were 2, this retainer would draw a fresh frame every 
	 * other frame.  So in a 60Hz game, the UI would render at 30Hz.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Render Rules", meta=(UIMin=1, ClampMin=1))
	int32 PhaseCount = 1;

	/**/
	UFUNCTION(BlueprintCallable, Category = "Fake3D")
	void SetRotation(FRotator NewRotation);

	/**/
	UFUNCTION(BlueprintCallable, Category = "Fake3D")
	void SetFOV(float NewFOV);

	/**/
	UFUNCTION(BlueprintCallable, Category = "Fake3D")
	void SetPivot(FVector2D NewPivot);

	/**
	* Requests the retainer redrawn the contents it has.
	*/
	UFUNCTION(BlueprintCallable, Category="Render Rules")
	void SetRenderingPhase(int32 RenderPhase, int32 TotalPhases);

	/**
	 * Should this widget redraw the contents it has every time the phase occurs.
	 */
	UFUNCTION(BlueprintCallable, Category="Render Rules")
	void SetRenderOnPhase(bool InRenderOnPhase);

	/**
	 * Requests the Fake3D redrawn the contents it has.
	 */
	UFUNCTION(BlueprintCallable, Category="Fake3D")
	void RequestRender();
	
#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override;
#endif
	
public:
	// UVisual interface
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;
	// End of UVisual interface
	
protected:

	// UWidget interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	virtual void SynchronizeProperties() override;
	// End of UWidget interface

	//~ Begin UPanelWidget interface
	virtual void OnSlotAdded(UPanelSlot* InSlot) override;
	virtual void OnSlotRemoved(UPanelSlot* InSlot) override;
	//~ End UPanelWidget interface

protected:
	TSharedPtr<SFake3DWidgetBox> MyFake3DWidgetBox;
};
