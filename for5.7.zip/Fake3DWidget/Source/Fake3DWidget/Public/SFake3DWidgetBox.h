// Copyright lurongjiu 2026 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Styling/SlateBrush.h"
#include "FastUpdate/SlateInvalidationRoot.h"
#include "Input/HittestGrid.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SVirtualWindow.h"

class FFake3DWidgetRenderingResources;
class FWidgetRenderer;

/**
 * 
 */
class FAKE3DWIDGET_API SFake3DWidgetBox : public SCompoundWidget,  public FSlateInvalidationRoot
{
public:
	SLATE_BEGIN_ARGS(SFake3DWidgetBox)
	{
//		_RenderOnInvalidation = false;
		_RenderOnPhase = true;
		_Phase = 0;
		_PhaseCount = 1;
	}
	SLATE_DEFAULT_SLOT(FArguments, Content)
//		SLATE_ARGUMENT(bool, RenderOnInvalidation)
		SLATE_ARGUMENT(bool, RenderOnPhase)
		SLATE_ARGUMENT(int32, Phase)
		SLATE_ARGUMENT(int32, PhaseCount)
		SLATE_ARGUMENT(FName, StatId)
	SLATE_END_ARGS()

	SFake3DWidgetBox();
	~SFake3DWidgetBox();
	

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs);
	
	/** Requests that the retainer redraw the hosted content next time it's painted. */
	void RequestRender();
#if WITH_EDITOR
	void SetIsDesignTime(bool bInIsDesignTime);
	void SetShowEffectsInDesigner(bool bInShowEffectsInDesigner);
#endif

	void SetContent(const TSharedRef< SWidget >& InContent);

	// SCompoundWidget interface
	virtual int32 OnPaint( const FPaintArgs& Args, const FGeometry& AllottedGeometry, const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId, const FWidgetStyle& InWidgetStyle, bool bParentEnabled ) const override;
	virtual FVector2D ComputeDesiredSize(float Scale) const override;
	
	//~ Begin FSlateInvalidationRoot interface
	virtual TSharedRef<SWidget> GetRootWidget() override;
	virtual int32 PaintSlowPath(const FSlateInvalidationContext& Context) override;
	enum class EPaintFake3DContentResult
	{
		NotPainted,
		Painted,
		Queued,
		TextureSizeTooBig,
		TextureSizeZero,
	};
	//只管理重绘RT, 不计算点位
	EPaintFake3DContentResult PaintFake3DContentImpl(const FSlateInvalidationContext& Context, const FGeometry& AllottedGeometry, int32 LayerId);

	bool IsAnythingVisibleToRender() const;

private:
	FRotator Rotation3D = FRotator::ZeroRotator;
	float PerspectiveRaw = 1.f;
	FVector2D Pivot = FVector2D(0.5f, 0.5f);
	bool HasFaceToRender = true;
	bool RenderFrontFace = true;
	bool RenderBackFace = false;

public:
	void SetRotation(const FRotator& InRotation);
	void SetFOV_Perspective(float InFOV);
	void SetPivot(FVector2D InPivot);
	void UpdateFrontFace(bool Front);
	void UpdateBackFace(bool Back);
	void SetWorld(UWorld* World);

	void SetRenderingPhase(int32 InPhase, int32 InPhaseCount);
	void SetRenderOnPhase(bool InRenderOnPhase);
	
private:
	//同时受到rotation, RenderFrontFace, RenderBackFace影响, 任何一个变量更新都需要调用该函数
	void UpdateFaceRender();
private:
	TSharedPtr<SWidget> ChildWidget;
	//用于独立绘制的窗口
	TSharedRef<SVirtualWindow> VirtualWindow;
	//独立绘制的必须对象
	TSharedRef<FHittestGrid> HittestGrid;

	mutable FSlateBrush BrushTL;
	mutable FSlateBrush BrushBR;
	//mutable bool bIsDirty = false;

	bool bRenderRequested;
	
	FIntPoint PreviousRenderSize;

	//RT绘制及缓存
	FFake3DWidgetRenderingResources* RenderingResources;
	//todo: 下个版本开发. 自定义命中测试
	TSharedPtr<ICustomHitTestPath> Fake3DHitTestPath;

#if WITH_EDITOR
	/** True if widget is used in design time */
	bool bIsDesignTime;
	/** True if we should retain rendering in designer */
	bool bShowEffectsInDesigner;
#endif

//	bool RenderOnInvalidation;
	bool RenderOnPhase;
	int32 Phase;
	int32 PhaseCount;

	int64 LastTickedFrame;

	TWeakObjectPtr<UWorld> OuterWorld;

	//用于性能统计
	STAT(TStatId MyStatId;)

	void UpdateWidgetRenderer();
	
	void Calc4Verts(const FGeometry& AllottedGeometry, TArray<FSlateVertex>& Vertices, TArray<float>& Zs) const;
};


