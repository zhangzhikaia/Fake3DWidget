// Copyright Epic Games, Inc. All Rights Reserved.

#include "Fake3DWidgetModule.h"

#define LOCTEXT_NAMESPACE "FFake3DWidgetModule"

void FFake3DWidgetModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
}

void FFake3DWidgetModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

const FString& FFake3DWidgetUtilities::GetContentDir()
{
	static FString CachedPath = []()
	{
		TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("Fake3DWidget"));

		check(Plugin.IsValid());

		return Plugin->GetContentDir();
	}();

	return CachedPath;
	
}

const FString& FFake3DWidgetUtilities::GetMatDir()
{
	static FString MatDir = TEXT("/Fake3DWidget/M_PerspectiveCorrectInterpolation.M_PerspectiveCorrectInterpolation");
	return MatDir;
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FFake3DWidgetModule, Fake3DWidget)