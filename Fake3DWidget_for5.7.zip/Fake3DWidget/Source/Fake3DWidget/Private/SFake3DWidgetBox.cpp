// Copyright lurongjiu 2026 All Rights Reserved.


#include "SFake3DWidgetBox.h"
#include "CanvasItem.h"
#include "Fake3DWidgetModule.h"
#include "RenderGraphBuilder.h"
#include "Slate/WidgetRenderer.h"
#include "Engine/TextureRenderTarget2D.h"
#include "SlateOptMacros.h"
#include "CanvasTypes.h"
#include "RHIFeatureLevel.h"
#include "RenderDeferredCleanup.h"
#include "Blueprint/SlateBlueprintLibrary.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Input/HittestGrid.h"
#include "Slate/SlateTextures.h"

class FFake3DHitTester : public ICustomHitTestPath
{
public:
	//todo: 实现3d测试变换
	virtual TArray<FWidgetAndPointer> GetBubblePathAndVirtualCursors( const FGeometry& InGeometry, FVector2D DesktopSpaceCoordinate, bool bIgnoreEnabledStatus ) const override
	{
		//最先被调用的, 此处返回空数组, 后两个函数不会被调用
		//DebugHelper::Print("GetBubblePathAndVirtualCursors", FColor::Red);
		return TArray<FWidgetAndPointer>();
	}
	
	virtual void ArrangeCustomHitTestChildren( FArrangedChildren& ArrangedChildren ) const override
	{
		//DebugHelper::Print("ArrangeCustomHitTestChildren", FColor::Green);
	}
	
	virtual TOptional<FVirtualPointerPosition> TranslateMouseCoordinateForCustomHitTestChild(const SWidget& ChildWidget, const FGeometry& MyGeometry, const FVector2D ScreenSpaceMouseCoordinate, const FVector2D LastScreenSpaceMouseCoordinate) const  override
	{
		//DebugHelper::Print(ScreenSpaceMouseCoordinate.ToString());
		return TOptional<FVirtualPointerPosition>();
	}
};

DECLARE_CYCLE_STAT(TEXT("Fake3D Widget Tick"), STAT_SlateFake3DWidgetTick, STATGROUP_Slate);
DECLARE_CYCLE_STAT(TEXT("Fake3D Widget Paint"), STAT_SlateFake3DWidgetPaint, STATGROUP_Slate);


class FFake3DWidgetRenderingResources : public FDeferredCleanupInterface, public FGCObject
{
public:
	FFake3DWidgetRenderingResources()
		: WidgetRenderer(nullptr)
		, RenderTarget(nullptr)
		, PerspectiveMaterialTL(nullptr)
		, PerspectiveMaterialBR(nullptr)
	{}

	~FFake3DWidgetRenderingResources()
	{
		// Note not using deferred cleanup for widget renderer here as it is already in deferred cleanup
		if (WidgetRenderer)
		{
			delete WidgetRenderer;
		}
	}

	/** FGCObject interface */
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override
	{
		Collector.AddReferencedObject(RenderTarget);
		Collector.AddReferencedObject(PerspectiveMaterialTL);
		Collector.AddReferencedObject(PerspectiveMaterialBR);
	}

	virtual FString GetReferencerName() const override
	{
		return TEXT("FFake3DWidgetRenderingResources");
	}
	
public:
	FWidgetRenderer* WidgetRenderer;
	TObjectPtr<UTextureRenderTarget2D> RenderTarget;
	TObjectPtr<UMaterialInstanceDynamic> PerspectiveMaterialTL;
	TObjectPtr<UMaterialInstanceDynamic> PerspectiveMaterialBR;
};


BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION

SFake3DWidgetBox::SFake3DWidgetBox()
:RenderingResources(new FFake3DWidgetRenderingResources)
, VirtualWindow(SNew(SVirtualWindow))
, HittestGrid(MakeShared<FHittestGrid>())
{
	SetInvalidationRootWidget(*this);
	SetInvalidationRootHittestGrid(HittestGrid.Get());
	SetCanTick(false);
}

SFake3DWidgetBox::~SFake3DWidgetBox()
{
	BeginCleanup(RenderingResources);
}

void SFake3DWidgetBox::Construct(const FArguments& InArgs)
{
	STAT(MyStatId = FDynamicStats::CreateStatId<FStatGroup_STATGROUP_Slate>(InArgs._StatId);)
	
	ChildWidget = InArgs._Content.Widget;

	//创建并初始化一个专用RT资源
	UTextureRenderTarget2D* RenderTarget = NewObject<UTextureRenderTarget2D>();
	RenderTarget->ClearColor = FLinearColor::Transparent;
	RenderTarget->RenderTargetFormat = RTF_RGBA8_SRGB;
	RenderingResources->RenderTarget = RenderTarget;

	//构造时先用rt设置笔刷, 实际马上就会用材质替代, 这里是一层可能多余的保险
	BrushTL.SetResourceObject(RenderingResources->RenderTarget);
	BrushBR.SetResourceObject(RenderingResources->RenderTarget);
	
	//创建动态材质示例并设置笔刷.不在构造时设置材质
	/*if (UMaterialInterface* BaseMat = LoadObject<UMaterialInterface>(nullptr,FFake3DWidgetUtilities::GetMatDir()))
	{
		RenderingResources->PerspectiveMaterialTL = UMaterialInstanceDynamic::Create(BaseMat,GetTransientPackage());
		RenderingResources->PerspectiveMaterialBR = UMaterialInstanceDynamic::Create(BaseMat,GetTransientPackage());

		//只需设置点A为TL和BR,就可以构造两个三角形,TR和BL固定两点即可
		RenderingResources->PerspectiveMaterialTL->SetVectorParameterValue("PointA",FLinearColor(0.f, 0.f, 0.f, 0.f));
		RenderingResources->PerspectiveMaterialBR->SetVectorParameterValue("PointA",FLinearColor(1.f, 1.f, 1.f, 1.f));
		
		BrushTL.SetResourceObject(RenderingResources->PerspectiveMaterialTL);
		BrushBR.SetResourceObject(RenderingResources->PerspectiveMaterialBR);
	}
	else
	{
		RenderingResources->PerspectiveMaterialTL = nullptr;
		RenderingResources->PerspectiveMaterialBR = nullptr;
		BrushTL.SetResourceObject(RenderingResources->RenderTarget);
		BrushBR.SetResourceObject(RenderingResources->RenderTarget);
	}*/

	VirtualWindow->SetVisibility(EVisibility::SelfHitTestInvisible);  
	VirtualWindow->SetShouldResolveDeferred(false);
	
	UpdateWidgetRenderer();
	
	//建立fake3D命中测试对象
	Fake3DHitTestPath = MakeShareable(new FFake3DHitTester());

	//初始化变量
#if WITH_EDITOR
	bIsDesignTime = false;
	bShowEffectsInDesigner = true;
#endif
	//RenderOnInvalidation = InArgs._RenderOnInvalidation;
	RenderOnPhase = InArgs._RenderOnPhase;
	Phase = InArgs._Phase;
	PhaseCount = InArgs._PhaseCount;

	LastTickedFrame = 0;
	
	bRenderRequested = true;
	
	ChildSlot
	[
		ChildWidget.ToSharedRef()
	];
}

void SFake3DWidgetBox::RequestRender()
{
	bRenderRequested = true;
	InvalidateRootChildOrder();
}

#if WITH_EDITOR
void SFake3DWidgetBox::SetIsDesignTime(bool bInIsDesignTime)
{
	bIsDesignTime = bInIsDesignTime;
}

void SFake3DWidgetBox::SetShowEffectsInDesigner(bool bInShowEffectsInDesigner)
{
	bShowEffectsInDesigner = bInShowEffectsInDesigner;
	//UpdateFaceRender();
}

#endif

void SFake3DWidgetBox::SetContent(const TSharedRef<SWidget>& InContent)
{
	ChildWidget = InContent;
	ChildSlot
	[
		InContent
	];
}

int32 SFake3DWidgetBox::OnPaint(const FPaintArgs& Args, const FGeometry& AllottedGeometry,const FSlateRect& MyCullingRect, FSlateWindowElementList& OutDrawElements, int32 LayerId,const FWidgetStyle& InWidgetStyle, bool bParentEnabled) const
{
	bool bShouldFake3DRendering = true;
#if WITH_EDITOR
	bool bShouldSkipDesignerRendering = bIsDesignTime && !bShowEffectsInDesigner;
	bShouldFake3DRendering = !bShouldSkipDesignerRendering;
#endif // WITH_EDITOR
	//优先级0, 编辑器设置不显示效果, 直接绘制原始形态, 不计算以及不受任何其它变量影响. 非编辑器下不检查
	if(!bShouldFake3DRendering)
	{
		return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
	}
	//优先级1, 查询本面是否绘制, 若不绘制, 返回并不绘制任何内容. 应优先于检查旋转角度和子项有效性(本身受旋转角度影响以算入)
	if(!HasFaceToRender) return GetCachedMaxLayerId();
	
	//优先级2, 编辑器有效且本面绘制, 再次检查状态, 若无内容, 调用默认(或直接返回, 参考官方代码使用默认, 仍然不会渲染内容)
	if(!IsAnythingVisibleToRender())
	{
		return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
	}
	
	//debug作用, 不影响实现
	STAT(FScopeCycleCounter PaintCycleCounter(MyStatId););
	SFake3DWidgetBox* MutableThis = const_cast<SFake3DWidgetBox*>(this);
	SCOPE_CYCLE_COUNTER(STAT_SlateFake3DWidgetPaint);

	
	// Slate顶点. 深度. bound范围
	TArray<FSlateVertex> Vertices;
	TArray<float> Zs;

	Calc4Verts(AllottedGeometry, Vertices, Zs);

	
	//todo: 下个版本开发. 注册fake3D击中测试. 必须widget处于grid的widget数组才行, 子widget一定不处于(或主动添加), 所以只能检测自身
	if ( false/*Fake3DHitTestPath.IsValid() && Args.GetHittestGrid().ContainsWidget(this)*/)
	{
		//Args.GetHittestGrid().GetGridOrigin() 基本永远是(-8, -8
		//Args.GetHittestGrid().GetGridSize()   基本永远是(2576,1408
		//Args.GetHittestGrid().GetGridWindowOrigin()  基本永远是(0,0
		//todo:重设检测区域, 至少包裹旋转后范围. 以及该包裹框必须做本地变换, 否则无法适配widget的变形 . 不能在这改, 会修改全局偏移
		Args.GetHittestGrid().SetHittestArea(Args.GetHittestGrid().GetGridOrigin(),Args.GetHittestGrid().GetGridSize(),Args.GetHittestGrid().GetGridWindowOrigin());
		Args.GetHittestGrid().InsertCustomHitTestPath(this, Fake3DHitTestPath.ToSharedRef());
	}

	const bool bHittestCleared = HittestGrid->SetHittestArea(Args.GetHittestGrid().GetGridOrigin(), Args.GetHittestGrid().GetGridSize(), Args.GetHittestGrid().GetGridWindowOrigin());
	if (bHittestCleared)
	{
		MutableThis->RequestRender();
	}
	HittestGrid->SetOwner(this);
	HittestGrid->SetCullingRect(MyCullingRect);
	
	FPaintArgs NewArgs = Args.WithNewHitTestGrid(HittestGrid.Get());
	NewArgs.GetHittestGrid().SetUserIndex(Args.GetHittestGrid().GetUserIndex());
	
	//FPaintArgs NewArgs = Args.WithNewHitTestGrid(HittestGrid.Get());
	FSlateInvalidationContext Context(OutDrawElements, InWidgetStyle);
	Context.bParentEnabled = bParentEnabled;
	Context.bAllowFastPathUpdate = true;
	Context.LayoutScaleMultiplier = GetPrepassLayoutScaleMultiplier();
	Context.PaintArgs = &NewArgs;
	Context.IncomingLayerId = LayerId;
	Context.CullingRect = MyCullingRect;
	
	//执行Widget绘制到RT, 它不管理是否绘制到视口, 只管理是否重绘到RT
	EPaintFake3DContentResult PaintResult = MutableThis->PaintFake3DContentImpl(Context, AllottedGeometry, LayerId);

	//debug作用, 不影响实现
#if WITH_SLATE_DEBUGGING
	if (PaintResult == EPaintFake3DContentResult::NotPainted
		|| PaintResult == EPaintFake3DContentResult::TextureSizeZero
		|| PaintResult == EPaintFake3DContentResult::TextureSizeTooBig)
	{
		MutableThis->SetLastPaintType(ESlateInvalidationPaintType::None);
	}
#endif

	//优先级3, RT这次绘制到尺寸0, 直接返回不继续
	if (PaintResult == EPaintFake3DContentResult::TextureSizeTooBig)
    {
    	return SCompoundWidget::OnPaint(Args, AllottedGeometry, MyCullingRect, OutDrawElements, LayerId, InWidgetStyle, bParentEnabled);
    }
	else if (PaintResult == EPaintFake3DContentResult::TextureSizeZero)
	{
		return GetCachedMaxLayerId();
	}
	
	UTextureRenderTarget2D* RenderTarget = RenderingResources->RenderTarget;
	check(RenderTarget);

	UMaterialInstanceDynamic* PerspectiveMaterialTL = RenderingResources->PerspectiveMaterialTL;
	const bool bPerspectiveMaterialTLInUse = (PerspectiveMaterialTL != nullptr);
	if(bPerspectiveMaterialTLInUse)
	{
		//经测试position为固定1, 而非经过size及变换的, 且为2D, 固本设计中只需1个点的输入即可(TR和BL固定)
		PerspectiveMaterialTL->SetVectorParameterValue("Depth", FLinearColor(Zs[0], Zs[1], Zs[2], 0.f));
		PerspectiveMaterialTL->SetTextureParameterValue("ChildRT", RenderTarget);

		const FSlateResourceHandle HandleTL = FSlateApplication::Get().GetRenderer()->GetResourceHandle(BrushTL);

		FSlateDrawElement::MakeCustomVerts(
		OutDrawElements,
		LayerId,
		HandleTL,
		Vertices,
		{0,1,2},
		nullptr,
		0,
		0,
		/*ESlateDrawEffect::PreMultipliedAlpha | */ESlateDrawEffect::NoGamma
		);
	}
	UMaterialInstanceDynamic* PerspectiveMaterialBR = RenderingResources->PerspectiveMaterialBR;
	const bool bPerspectiveMaterialBRInUse = (PerspectiveMaterialBR != nullptr);
	if(bPerspectiveMaterialBRInUse)
	{
		PerspectiveMaterialBR->SetVectorParameterValue("Depth", FLinearColor(Zs[3], Zs[1], Zs[2], 0.f));
		PerspectiveMaterialBR->SetTextureParameterValue("ChildRT", RenderTarget);

		const FSlateResourceHandle HandleBR = FSlateApplication::Get().GetRenderer()->GetResourceHandle(BrushBR);
		// 绘制
		FSlateDrawElement::MakeCustomVerts(
			OutDrawElements,
			LayerId,
			HandleBR,
			Vertices,
			{3,1,2},
			nullptr,
			0,
			0,
			/*ESlateDrawEffect::PreMultipliedAlpha | */ESlateDrawEffect::NoGamma
		);
	}
	
	const bool bInheritedHittestability = Args.GetInheritedHittestability();
	const bool bOutgoingHittestability = bInheritedHittestability && GetVisibility().AreChildrenHitTestVisible();

	// add our widgets to the root hit test grid
	if (bOutgoingHittestability)
	{
		Args.GetHittestGrid().AddGrid(HittestGrid);
	}
	
	return GetCachedMaxLayerId();;
}

FVector2D SFake3DWidgetBox::ComputeDesiredSize(float Scale) const
{
	return ChildWidget->GetDesiredSize();
}

TSharedRef<SWidget> SFake3DWidgetBox::GetRootWidget()
{
	return SCompoundWidget::GetChildren()->GetChildAt(0);
}

int32 SFake3DWidgetBox::PaintSlowPath(const FSlateInvalidationContext& Context)
{
	HittestGrid->Clear();
	
	const FGeometry& OriginalPaintSpaceGeometry = GetPaintSpaceGeometry();
	FSlateRenderTransform SimplifiedRenderTransform(OriginalPaintSpaceGeometry.GetAccumulatedRenderTransform().GetMatrix().GetScale(), OriginalPaintSpaceGeometry.GetAccumulatedRenderTransform().GetTranslation());
	FTransform2D ScalePosTransform(OriginalPaintSpaceGeometry.Scale, OriginalPaintSpaceGeometry.AbsolutePosition);
	SimplifiedRenderTransform = Concatenate(SimplifiedRenderTransform, Inverse(ScalePosTransform));
	const FGeometry NewPaintSpaceGeometry = FGeometry::MakeRoot(OriginalPaintSpaceGeometry.GetLocalSize(), FSlateLayoutTransform(OriginalPaintSpaceGeometry.Scale, OriginalPaintSpaceGeometry.AbsolutePosition)).MakeChild(SimplifiedRenderTransform, FVector2D::ZeroVector);
	return SCompoundWidget::OnPaint(*Context.PaintArgs, NewPaintSpaceGeometry, Context.CullingRect, *Context.WindowElementList, Context.IncomingLayerId, Context.WidgetStyle, Context.bParentEnabled);
}

SFake3DWidgetBox::EPaintFake3DContentResult SFake3DWidgetBox::PaintFake3DContentImpl(const FSlateInvalidationContext& Context, const FGeometry& AllottedGeometry, int32 LayerId)
{
	//只处理绘制RT, 一般发生于子项变化, 尺寸变化. 旋转和透视值改变不重绘RT
	if (RenderOnPhase)
	{
		if (LastTickedFrame != GFrameCounter && (GFrameCounter % PhaseCount) == Phase)
		{
			// If doing some phase based invalidation, just redraw everything again
			bRenderRequested = true;
			InvalidateRootLayout();
		}
	}

	const FPaintGeometry PaintGeometry = AllottedGeometry.ToPaintGeometry();
	FSlateRenderTransform AccumulatedRenderTransform = PaintGeometry.GetAccumulatedRenderTransform();
	const FVector2f RenderSize = FVector2f(PaintGeometry.GetLocalSize()) * AccumulatedRenderTransform.GetMatrix().GetScale().GetVector();
	const FIntPoint RoundedRenderSize = RenderSize.IntPoint();
	
	if (RoundedRenderSize != PreviousRenderSize)
	{
		bRenderRequested = true;
		InvalidateRootLayout();
		PreviousRenderSize = RoundedRenderSize;
	}

	if(bRenderRequested)
	{
		// In order to get material parameter collections to function properly, we need the current world's Scene
		// properly propagated through to any widgets that depend on that functionality. The SceneViewport and RetainerWidget the 
		// only location where this information exists in Slate, so we push the current scene onto the current
		// Slate application so that we can leverage it in later calls.
		UWorld* TickWorld = OuterWorld.Get();
		if (TickWorld && TickWorld->Scene && IsInGameThread())
		{
			FSlateApplication::Get().GetRenderer()->RegisterCurrentScene(TickWorld->Scene);
		}
		else if (IsInGameThread())
		{
			FSlateApplication::Get().GetRenderer()->RegisterCurrentScene(nullptr);
		}
		
		LastTickedFrame = GFrameCounter;
		
		const uint32 RenderTargetWidth  = FMath::RoundToInt(FMath::Abs(RenderSize.X));
		const uint32 RenderTargetHeight = FMath::RoundToInt(FMath::Abs(RenderSize.Y));
		const bool bTextureIsTooLarge = FMath::Max(RenderTargetWidth, RenderTargetHeight) > GetMax2DTextureDimension();
		const bool bTextureSizeZero = (RenderTargetWidth == 0 || RenderTargetHeight == 0);
		if(bTextureIsTooLarge)
		{
			return EPaintFake3DContentResult::TextureSizeTooBig;
		}
		else if(bTextureSizeZero)
		{
			return EPaintFake3DContentResult::TextureSizeZero;
		}

		if (RenderTargetWidth >= 1 && RenderTargetHeight >= 1)
		{
			const FVector2D ViewOffset = AllottedGeometry.ToPaintGeometry().GetAccumulatedRenderTransform().GetTranslation();

			UTextureRenderTarget2D* RenderTarget = RenderingResources->RenderTarget;
			FWidgetRenderer* WidgetRenderer = RenderingResources->WidgetRenderer;
	
			if ( (int32)RenderTarget->GetSurfaceWidth() != (int32)RenderTargetWidth ||
				 (int32)RenderTarget->GetSurfaceHeight() != (int32)RenderTargetHeight )
			{
				// If the render target resource already exists just resize it.  Calling InitCustomFormat flushes render commands which could result in a huge hitch
				if(RenderTarget->GameThread_GetRenderTargetResource() && RenderTarget->OverrideFormat == PF_B8G8R8A8)
				{
					RenderTarget->ResizeTarget(RenderTargetWidth, RenderTargetHeight);
				}
				else
				{
					const bool bForceLinearGamma = false;
					RenderTarget->InitCustomFormat(RenderTargetWidth, RenderTargetHeight, PF_B8G8R8A8, bForceLinearGamma);
					RenderTarget->UpdateResourceImmediate();
				}
			}
			
			const FVector2D DrawSize = FVector2D(RenderTargetWidth, RenderTargetHeight);
			// Update the surface brush to match the latest size.
			BrushTL.ImageSize = DrawSize;
			BrushBR.ImageSize = DrawSize;
			
			WidgetRenderer->ViewOffset = -ViewOffset;
			WidgetRenderer->SetIsPrepassNeeded(false);

			FVector2f WindowSize(RenderSize);
			SWindow* PaintWindow = Context.WindowElementList->GetPaintWindow();
			if (PaintWindow)
			{
				const FVector2f ViewportSize = PaintWindow->GetViewportSize();
				WindowSize.X = FMath::Max(WindowSize.X, ViewportSize.X);
				WindowSize.Y = FMath::Max(WindowSize.Y, ViewportSize.Y);
			}
			VirtualWindow->Resize(WindowSize);
			
			bool bRepaintedWidgets = WidgetRenderer->DrawInvalidationRoot(VirtualWindow, RenderTarget, *this, Context);

			//WidgetRenderer->DrawWidget(RenderingResources->RenderTarget,ChildWidget.ToSharedRef(),Size,0.f ); 
			bRenderRequested = false;
			
			return bRepaintedWidgets ? EPaintFake3DContentResult::Painted : EPaintFake3DContentResult::NotPainted;
		}
	}
	
	return EPaintFake3DContentResult::NotPainted;
}

bool SFake3DWidgetBox::IsAnythingVisibleToRender() const
{
	return ChildWidget.IsValid() && ChildWidget->GetVisibility().IsVisible();
}


void SFake3DWidgetBox::SetRotation(const FRotator& InRotation)
{
	Rotation3D = InRotation;
	UpdateFaceRender();
	//Invalidate(EInvalidateWidgetReason::Paint);
}

void SFake3DWidgetBox::SetFOV_Perspective(float InFOV)
{
	//FOV = InFOV;
	const float FOVRad = FMath::DegreesToRadians(InFOV);
	// 焦距
	PerspectiveRaw = 1.0f / FMath::Tan(FOVRad * 0.5f);
	//Invalidate(EInvalidateWidgetReason::Paint);
}

void SFake3DWidgetBox::SetPivot(FVector2D InPivot)
{
	Pivot = InPivot;
}

void SFake3DWidgetBox::UpdateFaceRender()
{
	/*if(bIsDesignTime && !bShowEffectsInDesigner)
	{
		HasFaceToRender = true;
		return;
	}*/
	if(RenderFrontFace && RenderBackFace)
	{
		HasFaceToRender = true;
		return;
	}
	if(!RenderFrontFace && !RenderBackFace)
	{
		HasFaceToRender = false;
		return;
	}
	
	FVector Normal = FVector::UpVector; //指面朝向(屏幕), 为(0,0,1)
	FVector RotatedNormal = Rotation3D.RotateVector(Normal);
	float Dot = FVector::DotProduct(RotatedNormal, Normal);
	
	if(Dot > 0 && RenderFrontFace)
	{
		HasFaceToRender = true;
	}
	else if(Dot < 0 && RenderBackFace)
	{
		HasFaceToRender = true;
	}
	else
	{
		HasFaceToRender = false;
	}
}

void SFake3DWidgetBox::UpdateFrontFace(bool Front)
{
	RenderFrontFace = Front;
	UpdateFaceRender();
}

void SFake3DWidgetBox::UpdateBackFace(bool Back)
{
	RenderBackFace = Back;
	UpdateFaceRender();
}

void SFake3DWidgetBox::SetWorld(UWorld* World)
{
	OuterWorld = World;
}

void SFake3DWidgetBox::SetEffectMaterial(UMaterialInterface* EffectMaterial)
{
	if ( EffectMaterial )
	{
		RenderingResources->PerspectiveMaterialTL = UMaterialInstanceDynamic::Create(EffectMaterial,GetTransientPackage());
		RenderingResources->PerspectiveMaterialBR = UMaterialInstanceDynamic::Create(EffectMaterial,GetTransientPackage());

		//只需设置点A为TL和BR,就可以构造两个三角形,TR和BL固定两点即可
		RenderingResources->PerspectiveMaterialTL->SetVectorParameterValue("PointA",FLinearColor(0.f, 0.f, 0.f, 0.f));
		RenderingResources->PerspectiveMaterialBR->SetVectorParameterValue("PointA",FLinearColor(1.f, 1.f, 1.f, 1.f));
		
		BrushTL.SetResourceObject(RenderingResources->PerspectiveMaterialTL);
		BrushBR.SetResourceObject(RenderingResources->PerspectiveMaterialBR);
	}
	else
	{
		RenderingResources->PerspectiveMaterialTL = nullptr;
		RenderingResources->PerspectiveMaterialBR = nullptr;
		BrushTL.SetResourceObject(RenderingResources->RenderTarget);
		BrushBR.SetResourceObject(RenderingResources->RenderTarget);
	}

	UpdateWidgetRenderer();
}

void SFake3DWidgetBox::SetRenderingPhase(int32 InPhase, int32 InPhaseCount)
{
	Phase = InPhase;
	PhaseCount = InPhaseCount;
}

void SFake3DWidgetBox::SetRenderOnPhase(bool InRenderOnPhase)
{
	RenderOnPhase = InRenderOnPhase;
}

void SFake3DWidgetBox::UpdateWidgetRenderer()
{
	// We can't write out linear.  If we write out linear, then we end up with premultiplied alpha
	// in linear space, which blending with gamma space later is difficult...impossible? to get right
	// since the rest of slate does blending in gamma space.
	const bool bWriteContentInGammaSpace = true;
	if (!RenderingResources->WidgetRenderer)
	{
		RenderingResources->WidgetRenderer = new FWidgetRenderer(bWriteContentInGammaSpace);
	}
	UTextureRenderTarget2D* RenderTarget = RenderingResources->RenderTarget;
	FWidgetRenderer* WidgetRenderer = RenderingResources->WidgetRenderer;
	
	WidgetRenderer->SetUseGammaCorrection(bWriteContentInGammaSpace);

	// This will be handled by the main slate rendering pass
	WidgetRenderer->SetApplyColorDeficiencyCorrection(false);

	WidgetRenderer->SetIsPrepassNeeded(false);
	WidgetRenderer->SetClearHitTestGrid(false);
	// Update the render target to match the current gamma rendering preferences.
	if (RenderTarget && RenderTarget->SRGB != !bWriteContentInGammaSpace)
	{
		// Note, we do the opposite here of whatever write is, if we we're writing out gamma,
		// then sRGB writes were not supported, so it won't be an sRGB texture.
		RenderTarget->TargetGamma = !bWriteContentInGammaSpace ? 0.0f : 1.0;
		RenderTarget->SRGB = !bWriteContentInGammaSpace;

		RenderTarget->UpdateResource();
	}
}

void SFake3DWidgetBox::Calc4Verts(const FGeometry& AllottedGeometry, TArray<FSlateVertex>& Vertices, TArray<float>& Zs) const
{
	const FVector2D Size = AllottedGeometry.GetLocalSize();
	
	//确保最终Z值为正. Z值只要比例正确, 按尺寸扩大倍数不影响最终结果. 该值经测试应与Perspective呈相关性
	//const float Length = Size.X + Size.Y;
	//将fov按Size.X + Size.Y倍数扩大, 可以确保Z最终计算得正值
	float PerspectiveFix = PerspectiveRaw * (Size.X + Size.Y);
	
	// 归一化 Pivot -> 实际像素位置
	const FVector2D PivotPos = Size * Pivot;
	
	FVector LocalVerts[4] =
	{
		FVector(   0.f - PivotPos.X,	0.f - PivotPos.Y, 0.f),// TL
		FVector(Size.X - PivotPos.X,	0.f - PivotPos.Y, 0.f),// TR
		FVector(   0.f - PivotPos.X, Size.Y - PivotPos.Y, 0.f),// BL
		FVector(Size.X - PivotPos.X, Size.Y - PivotPos.Y, 0.f) // BR
	};
	// 旋转矩阵
	const FMatrix RotMatrix = FRotationMatrix(Rotation3D);
	FVector2D FinalVerts[4];
	
	Zs.SetNum(4);
	
	for (int32 i = 0; i < 4; ++i)
	{
		// 3D旋转
		FVector P = RotMatrix.TransformPosition(LocalVerts[i]);
		
		// 透视
		float Z = PerspectiveFix - P.Z;

		Z = FMath::Max(Z, 1.f);

		float Scale = PerspectiveFix / Z;

		FVector2D Projected(P.X * Scale, P.Y * Scale);

		// 平移回控件中心
		Projected += PivotPos;
		// 转DrawSpace
		FinalVerts[i] = AllottedGeometry.LocalToAbsolute(Projected);

		//1. FOV为72时矫正的刚刚好完美,FOV越大,需要越强的矫正 2.这里的倍数完全不影响结果(每个Z等比缩放不影响结果) 3.这里增加的值影响FOV的基准角度(例如加10000, FOV变成50多比例正确而不是72)
		//所以应该: FOV减小, 加大该值(不是成倍数), FOV加大, 减小该值  且必须保证结果为正值

		//虽然这样矫正结果完美, 但当P.Z + PerspectiveFix仍为负值时(P.Z一定有为负的, 当PerspectiveFix不足以弥补P.Z小于0的部分时, 将出现错误. 一般在FOV过大时)
		Zs[i] = P.Z + PerspectiveFix;

	}

	TTransform2<float> Transform = Concatenate(TScale2<float>(1.f, 1.f), UE::Math::TVector2<float>(0.f, 0.f));
	Vertices.SetNum(4);
	
	// TL
	Vertices[0] = FSlateVertex::Make<ESlateVertexRounding::Disabled>(
			Transform,
			FVector2f(FinalVerts[0]),
			FVector2f(0,0),
			FColor::White
		);
	
	// TR
	Vertices[1] = FSlateVertex::Make<ESlateVertexRounding::Disabled>(
			Transform,
			FVector2f(FinalVerts[1]),
			FVector2f(1,0),
			FColor::White
		);
	
	// BL
	Vertices[2] = FSlateVertex::Make<ESlateVertexRounding::Disabled>(
		Transform,
		FVector2f(FinalVerts[2]),
		FVector2f(0,1),
		FColor::White
	);
	
	// BR
	Vertices[3] = FSlateVertex::Make<ESlateVertexRounding::Disabled>(
		Transform,
		FVector2f(FinalVerts[3]),
		FVector2f(1,1),
		FColor::White
	);
}

END_SLATE_FUNCTION_BUILD_OPTIMIZATION
