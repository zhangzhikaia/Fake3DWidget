// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Interfaces/IPluginManager.h"
#include "Engine.h"
#include "Kismet/KismetStringLibrary.h"
#include "Modules/ModuleManager.h"

class FFake3DWidgetModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	
};

namespace DebugHelper
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *message);
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(int message, FColor color = FColor::Blue)
	{
		UE_LOG(LogTemp, Warning, TEXT("%s"), *FString::FromInt(message));
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
	static void Print(const double& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%f"),message);
	}
	
}


class FFake3DWidgetUtilities
{
public:

	static const FString& GetContentDir();
	
	static const FString& GetMatDir();
};